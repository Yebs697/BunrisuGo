package bunrisugo.attendance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

import bunrisugo.util.CommonDBConnection;

public class AttendanceDAO {

    // 1. 화면 데이터 조회 (테스트용: 버튼 항상 활성화)
    public AttendanceDTO getAttendanceData(String userIdentifier) {
        AttendanceDTO dto = new AttendanceDTO();
        
        // SQL은 동일
        String sql_points = "SELECT total_points FROM Points WHERE user_identifier = ?";
        String sql_last = "SELECT attend_date, consecutive_count FROM Attendance WHERE user_identifier = ? ORDER BY attend_id DESC LIMIT 1";
        String sql_cumul = "SELECT COUNT(attend_id) FROM Attendance WHERE user_identifier = ?";

        try (Connection conn = CommonDBConnection.getConnection();
             PreparedStatement pstmt_points = conn.prepareStatement(sql_points);
             PreparedStatement pstmt_last = conn.prepareStatement(sql_last);
             PreparedStatement pstmt_cumul = conn.prepareStatement(sql_cumul)) {

            // 포인트 & 누적일 조회
            pstmt_points.setString(1, userIdentifier);
            ResultSet rs = pstmt_points.executeQuery();
            if (rs.next()) dto.setTotalPoints(rs.getInt(1));

            pstmt_cumul.setString(1, userIdentifier);
            ResultSet rs2 = pstmt_cumul.executeQuery();
            if (rs2.next()) dto.setCumulativeDays(rs2.getInt(1));

            // 마지막 출석 조회
            pstmt_last.setString(1, userIdentifier);
            ResultSet rs3 = pstmt_last.executeQuery();
            if (rs3.next()) {
                int consecutive = rs3.getInt("consecutive_count");
                
                // ★★★ [테스트용 수정] ★★★
                // 오늘 출석 했든 안 했든 무조건 "안 했다"고 거짓말쳐서 버튼 활성화
                dto.setTodayAttended(false); 
                
                // 연속 일수는 그대로 보여줌 (리셋 직후인 0일차면 0으로 표시)
                dto.setConsecutiveDays(consecutive);
            } else {
                dto.setTodayAttended(false);
                dto.setConsecutiveDays(0);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return dto;
    }

    // 2. 출석 체크 실행 (테스트용: 무한 증가 & 7일 리셋)
    public String performCheckIn(String userIdentifier) {
        Connection conn = null;
        PreparedStatement pstmt_last = null;
        PreparedStatement pstmt_insert = null;
        PreparedStatement pstmt_update = null;
        PreparedStatement pstmt_history = null;

        try {
            conn = CommonDBConnection.getConnection();
            conn.setAutoCommit(false); 

            // (1) 마지막 기록 확인
            String sql_last = "SELECT consecutive_count FROM Attendance WHERE user_identifier = ? ORDER BY attend_id DESC LIMIT 1";
            pstmt_last = conn.prepareStatement(sql_last);
            pstmt_last.setString(1, userIdentifier);
            ResultSet rs = pstmt_last.executeQuery();

            int newConsecutive = 1;
            if (rs.next()) {
                // ★★★ [테스트용 수정] ★★★
                // 날짜 비교 로직 삭제! 무조건 기존 값에 +1
                newConsecutive = rs.getInt("consecutive_count") + 1;
            }

            // (2) 보너스 계산 & 리셋
            int pointsToAdd = 10;
            boolean bonusHit = false;
            String msg = "출석 완료! +10p (현재 " + newConsecutive + "일차)";

            if (newConsecutive >= 7) { // 7일 도달 시
                pointsToAdd = 40; // 10 + 30
                bonusHit = true;
                msg = "🎉 7일 연속 보너스! +40p (다음부터 1일차)";
                
                // ★★★ [리셋] 다음 클릭 시 1일차가 되도록 0 저장
                newConsecutive = 0; 
            }

            // (3) DB 저장 (Attendance)
            String sql_insert = "INSERT INTO Attendance (user_identifier, attend_date, points_earned, is_consecutive_bonus, consecutive_count) VALUES (?, NOW(), ?, ?, ?)";
            pstmt_insert = conn.prepareStatement(sql_insert);
            pstmt_insert.setString(1, userIdentifier);
            pstmt_insert.setInt(2, pointsToAdd);
            pstmt_insert.setInt(3, bonusHit ? 1 : 0);
            pstmt_insert.setInt(4, newConsecutive);
            pstmt_insert.executeUpdate();

            // (4) DB 저장 (Points)
            String sql_update = "INSERT INTO Points (user_identifier, total_points, last_update_date) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE total_points = total_points + ?, last_update_date = NOW()";
            pstmt_update = conn.prepareStatement(sql_update);
            pstmt_update.setString(1, userIdentifier);
            pstmt_update.setInt(2, pointsToAdd);
            pstmt_update.setInt(3, pointsToAdd);
            pstmt_update.executeUpdate();

            // (5) DB 저장 (History)
            String sql_hist = "INSERT INTO Point_History (user_identifier, change_type, points_change, change_date) VALUES (?, ?, ?, NOW())";
            pstmt_history = conn.prepareStatement(sql_hist);
            pstmt_history.setString(1, userIdentifier);
            pstmt_history.setString(2, bonusHit ? "7일 연속 보너스" : "출석 체크");
            pstmt_history.setInt(3, pointsToAdd);
            pstmt_history.executeUpdate();

            conn.commit();
            return msg;

        } catch (SQLException e) {
            try { if (conn != null) conn.rollback(); } catch (SQLException ex) {}
            e.printStackTrace();
            return "오류: " + e.getMessage();
        } finally {
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }

    // 3. 내역 조회 (동일)
    public DefaultTableModel getPointHistory(String userIdentifier) {
        Vector<String> cols = new Vector<>();
        cols.add("날짜"); cols.add("활동"); cols.add("포인트");
        Vector<Vector<Object>> data = new Vector<>();

        // 100줄까지 보이게 수정함
        String sql = "SELECT change_date, change_type, points_change FROM Point_History WHERE user_identifier = ? ORDER BY change_date DESC LIMIT 100";

        try (Connection conn = CommonDBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, userIdentifier);
            ResultSet rs = pstmt.executeQuery();
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"); // 시:분 까지 나오게 수정
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getTimestamp("change_date").toLocalDateTime().format(fmt));
                row.add(rs.getString("change_type"));
                row.add("+" + rs.getInt("points_change"));
                data.add(row);
            }
        } catch (Exception e) { e.printStackTrace(); }
        
        return new DefaultTableModel(data, cols) {
             @Override public boolean isCellEditable(int row, int col) { return false; }
        };
    }
}